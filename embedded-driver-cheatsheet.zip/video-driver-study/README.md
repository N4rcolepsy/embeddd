# 임베디드 드라이버 개발 온보딩 노트

**대상 영상:** [(Sponsored) How To Write A Driver (STM32, I2C, Datasheet) — Phil's Lab #30](https://www.youtube.com/watch?v=_JQAve05o_0), 2021-08-20 공개, 약 38분 20초.

**학습 목표:** 데이터시트·레지스터 맵을 읽고 C/C++ 드라이버의 구조를 이해하여, 새 장치의 초기화와 데이터 읽기를 직접 구현할 수 있게 한다. 링크는 21:38에서 시작하지만 영상 전체를 정리했다.

## 읽는 순서

**현재 업무는 ST HAL을 쓰지 않는 주소 + memory read/write 기반 구현이다.** [07 — 바닥부터 메모리 드라이버 구현](07-memory-io-from-scratch.md)과 [ST 의존 없는 C 템플릿](examples/memory_io/README.md)을 먼저 읽는다. 기존 05·06의 STM32 예제는 영상 비교 학습용으로 보존했다.

전체 내용을 한 파일로 읽으려면 [통합 Markdown](driver-onboarding-complete.md)을 연다. 아래 개별 문서는 필요한 내용을 찾아볼 때 사용한다.

인쇄하거나 구현 중 빠르게 찾아보려면 [22쪽 치트시트와 스니펫 50개](cheatsheet/README.md)를 사용한다. **2~7쪽이 현재 업무의 우선 경로**다. PDF와 복사용 Markdown을 함께 제공한다.

| 문서 | 무엇을 얻는가 |
|---|---|
| [00 — 빠른 온보딩 경로](00-onboarding-fast-track.md) | 먼저 배울 개념, 2~3시간 학습 경로, 실제 구현 순서 |
| [01 — 영상 상세 정리](01-video-detailed-notes.md) | 시간대별 내용과 데이터시트가 코드가 되는 과정 |
| [02 — 영상의 디자인 패턴 분석](02-video-design-patterns.md) | 구조체·핸들·계층화·초기화·측정 파이프라인의 설계 이유 |
| [03 — 데이터시트 기반 공통 드라이버 패턴](03-datasheet-driver-patterns.md) | 다른 장치에 적용하는 추출표, 구현 계약, 설계 체크리스트 |
| [04 — C/C++ 핵심 문법](04-c-cpp-core.md) | 포인터·함수 포인터·struct·union부터 C++ 인터페이스까지 |
| [05 — HAL과 LL 상세 설명](05-hal-and-ll-explained.md) | 추상화 범위·핸들·I²C 전송·IRQ/DMA·혼용·선택 기준 |
| [06 — UART 템플릿과 C의 가변 인자](06-uart-handle-and-variadic.md) | 실제 HAL handle로 초기화·송신하기, `...`와 stdarg 이해 |
| [07 — 주소와 메모리 명령으로 직접 구현](07-memory-io-from-scratch.md) | 주소 공간·폭·정렬·register 정책·내 UART·timeout·barrier·포팅 |
| [memory_io C 템플릿](examples/memory_io/README.md) | HAL 없는 read/write 연결, handle, polling TX/Flush, fake register 테스트 |
| [해독 실습 코드](examples/measurement_decode.c) | 하드웨어 없이 살펴보는 12/20비트 해독과 대표값 |
| [출처와 검토 범위](sources/README.md) | 사용한 원자료와 확인 방법, 자료별 차이 |

현재 업무는 **07 → memory_io 소스 → 내 장치에 03 적용** 순서로 시작하고, 문법이 막힐 때 04를 찾아본다. 영상의 학습 경로는 00 → 02이며, 영상을 함께 따라가려면 01부터 읽는다. IRQ·DMA·동시성은 그 기능을 맡을 때 확장한다.

## 자료의 구분

- **영상 정리:** 원문의 전체 번역이나 대본이 아니라, 기술적인 흐름을 한국어로 재구성한 학습 노트다.
- **패턴 해석:** 영상의 코드 구조가 어떤 설계 문제를 푸는지 분석한 내용이다. 강의자가 그 패턴 이름을 직접 사용했다는 뜻은 아니다.
- **확장 학습:** 함수 포인터 기반 버스 분리, 상태 관리, C++·DMA 등 영상 범위를 넘어서는 내용은 별도로 설명한다.
- **정확성 참고:** 예전 강의와 현재 자료의 차이는 온보딩에 필요한 만큼만 분리했다. 오류 찾기가 이 자료의 주목적은 아니다.

영상·기존 자료의 검토 기준일은 2026-08-31이며, 메모리 명령 기반 구현과 치트시트는 2026-09-01에 보완했다. 전체 영어 자동 자막을 읽고 주요 코드 화면, 제작자의 공개 소스, 제조사·공식 기술 자료를 대조했다. 동영상을 전 구간 연속 재생해 모든 프레임을 확인한 것은 아니다. C/C++ 예제는 교육용이며 실제 보드에서 실행·검증된 제품 드라이버가 아니다.

검증: ST 의존 없는 memory_io는 C17 debug/최적화 빌드와 fake register 시험을 통과했다. decode·가변 인자 호스트 C 예제도 실행했다. [실행 결과](examples/memory_io/verification.json). 전체 HAL 프로젝트·모든 스니펫·C++·실물은 시험하지 않았다.
